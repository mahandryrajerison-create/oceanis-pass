# Oceanis Pass-Rewards — application Android multi-téléphones

Tous les téléphones partagent en temps réel les entreprises, les cartes et les passages. Les gardiens scannent même sans réseau : les passages partent dès que la connexion revient.

Il y a **trois étapes, à faire une seule fois** : le serveur (Firebase, gratuit), l'APK (GitHub, gratuit), puis les comptes.

## 1. Créer le serveur Firebase (10 min)
1. Allez sur https://console.firebase.google.com → **Ajouter un projet** (nom : `oceanis-pass`, Analytics inutile).
2. **Build → Authentication → Commencer → Adresse e-mail/Mot de passe → Activer**.
3. **Build → Firestore Database → Créer une base** → mode **production** → région `eur3` ou `europe-west1`.
4. Onglet **Règles** : remplacez tout par le contenu du fichier `firestore.rules`, puis **Publier**.
5. **Paramètres du projet (roue dentée) → Vos applications → icône `</>` (Web)** → nom `pass` → Enregistrer. Copiez le bloc `firebaseConfig = { … }` affiché.

Le forfait gratuit (Spark) suffit largement : 50 000 lectures et 20 000 écritures par jour.

## 2. Obtenir l'APK
1. Créez un dépôt **privé** sur GitHub et envoyez-y le contenu de ce dossier (sans `node_modules`).
2. Onglet **Actions → Compiler l'APK → Run workflow**. Après ~6 minutes, téléchargez l'artefact **Pass-Rewards-APK** (fichier `app-debug.apk`).
3. Envoyez l'APK aux téléphones (WhatsApp, câble, Drive) et installez-le (autoriser « sources inconnues »).

Alternative : ouvrez le dossier `android/` dans Android Studio → Build → Build APK.

## 3. Premier démarrage
1. Sur **votre** téléphone : ouvrir l'application → **Connecter ce téléphone au serveur** → coller le `firebaseConfig` → **Premier démarrage : créer le compte administrateur**.
2. **Réglages → Équipe et postes de garde** : créez un compte par portail (ex. identifiant `portail1`, mot de passe de 6 caractères minimum, rôle *Poste de garde*).
3. **Réglages → Inviter un téléphone (QR)** : sur chaque nouveau téléphone, choisissez *Connecter au serveur* et scannez le QR, puis connectez-vous avec le compte du poste.
4. Vos données de l'ancienne version (si vous en aviez) : *Réglages → Importer un fichier* avec la sauvegarde, une fois connecté.

## Ce que voit chacun
| | Administrateur | Poste de garde |
|---|---|---|
| Entreprises, cartes, import Excel, planches | oui | lecture seule |
| Scan, remises, passages | oui | oui (peut annuler un passage) |
| Chiffre d'affaires des événements, réglages | oui | non |
| Créer des comptes | oui | non |

## Bon à savoir
- **Mot de passe oublié d'un gardien** : retirez le compte puis recréez-en un avec un autre identifiant.
- **Plusieurs administrateurs** : ils peuvent travailler en même temps ; évitez toutefois que deux d'entre eux créent des cartes pour la **même entreprise** au même moment (numéros de carte identiques possibles).
- **Sécurité** : le serveur vérifie les droits (voir `firestore.rules`), pas seulement l'application. Les gardiens reçoivent les fiches entreprises (contact compris) mais pas les chiffres d'affaires.
- **Effacer tout** est désactivé quand le téléphone est synchronisé, pour ne pas supprimer les données de tous les postes.
- **Hors ligne** : un téléphone doit être connecté au moins une fois avec Internet. Ensuite il démarre et scanne sans réseau.
- **Sauvegarde** : Firebase conserve les données ; exportez tout de même une sauvegarde de temps en temps (Réglages).
