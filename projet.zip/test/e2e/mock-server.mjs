// Faux serveur Firebase : applique les mêmes droits que firestore.rules, pour tester l'interface de bout en bout.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../..');
const state = { users: {}, staff: {}, init: false, docs: { companies: {}, cards: {}, events: {}, visits: {} }, params: null };
const ROLE_READ = { admin: ['companies', 'cards', 'events', 'visits'], garde: ['companies', 'cards', 'visits'] };
const type = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.png': 'image/png', '.json': 'application/json' };
function staffOf(email) { return state.staff[email] || null; }
http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname.startsWith('/api/')) {
    let body = ''; req.on('data', c => body += c); req.on('end', () => {
      const b = body ? JSON.parse(body) : {}; const p = url.pathname.slice(5); if (process.env.DEBUG && p !== 'col' && p !== 'params-get') console.log(p, JSON.stringify(b).slice(0,150));
      const send = (code, o) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };
      const deny = () => send(403, { code: 'permission-denied' });
      const me = b.token, st = staffOf(me), admin = st && st.role === 'admin';
      switch (p) {
        case 'login': return state.users[b.email] === b.pw ? send(200, { ok: 1 }) : send(400, { code: 'auth/invalid-credential' });
        case 'register': if (state.users[b.email]) return send(400, { code: 'auth/email-already-in-use' }); state.users[b.email] = b.pw; return send(200, { ok: 1 });
        case 'register-admin-doc': if (state.init || me !== b.email) { delete state.users[b.email]; return deny(); } state.staff[b.email] = { role: 'admin', name: b.name }; state.init = true; return send(200, { ok: 1 });
        case 'init-get': return send(200, { init: state.init });
        case 'staff-get': if (!me || (me !== b.email && !admin)) return deny(); return send(200, { staff: staffOf(b.email) });
        case 'staff-list': if (!admin) return deny(); return send(200, { list: Object.entries(state.staff).map(([email, v]) => ({ email, ...v })) });
        case 'staff-add': if (!admin) return deny(); if (state.users[b.email]) return send(400, { code: 'auth/email-already-in-use' }); state.users[b.email] = b.pw; state.staff[b.email] = { role: b.role, name: b.name }; return send(200, { ok: 1 });
        case 'staff-del': if (!admin) return deny(); delete state.staff[b.email]; return send(200, { ok: 1 });
        case 'col': if (!st || !ROLE_READ[st.role].includes(b.col)) return deny(); return send(200, { docs: state.docs[b.col] });
        case 'set': {
          if (!st) return deny();
          if (b.col === 'visits') { const ex = state.docs.visits[b.id]; if (ex && !admin) { const keys = new Set([...Object.keys(ex), ...Object.keys(b.doc)]); for (const k of keys) if (!['void', 'updatedAt'].includes(k) && JSON.stringify(ex[k]) !== JSON.stringify(b.doc[k])) return deny(); } }
          else if (!admin || !state.docs[b.col]) return deny();
          state.docs[b.col][b.id] = b.doc; return send(200, { ok: 1 });
        }
        case 'del': if (!admin || !state.docs[b.col]) return deny(); delete state.docs[b.col][b.id]; return send(200, { ok: 1 });
        case 'params-get': if (!st) return deny(); return send(200, { doc: state.params });
        case 'params-set': if (!admin) return deny(); state.params = b.doc; return send(200, { ok: 1 });
        case '_state': return send(200, state);
        case '_reset': state.users = {}; state.staff = {}; state.init = false; state.params = null; for (const k in state.docs) state.docs[k] = {}; return send(200, {});
      }
      send(404, { code: 'nope' });
    });
    return;
  }
  if (url.pathname === '/cloud.bundle.js') {
    res.writeHead(200, { 'content-type': 'text/javascript' });
    return res.end(fs.readFileSync(path.join(root, 'src/sync-core.js')) + '\n' + fs.readFileSync(path.join(root, 'test/e2e/mock-cloud.js')));
  }
  const f = path.join(root, 'www', url.pathname === '/' ? 'index.html' : url.pathname);
  if (!f.startsWith(path.join(root, 'www')) || !fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'content-type': type[path.extname(f)] || 'application/octet-stream' }); res.end(fs.readFileSync(f));
}).listen(8790, () => console.log('mock sur 8790'));
