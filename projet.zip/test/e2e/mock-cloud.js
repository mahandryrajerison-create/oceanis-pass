/* Faux client Firebase pour les tests de bout en bout : même interface que window.OCPR_CLOUD,
   mais parle à mock-server.mjs (HTTP + interrogation toutes les 250 ms). Permet de simuler le réseau coupé. */
(function () {
  var DOMAIN = '@oceanis-pass.app', cfg = null, authCb = null, user = null;
  var mock = window.__mock = { queue: [], log: [] };
  Object.defineProperty(mock, 'offline', { get: function () { return sessionStorage.getItem('mock_off') === '1'; }, set: function (v) { sessionStorage.setItem('mock_off', v ? '1' : '0'); } });
  function toEmail(id) { id = String(id || '').trim().toLowerCase(); return id.indexOf('@') !== -1 ? id : id.replace(/[^a-z0-9._-]+/g, '') + DOMAIN; }
  function api(path, body) {
    if (mock.offline) return Promise.reject({ code: 'unavailable', message: 'offline' });
    return fetch('/api/' + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(Object.assign({ token: user && user.email }, body || {})) })
      .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw { code: j.code || 'error', message: j.code }; return j; }); });
  }
  function setUser(email) { user = email ? { email: email, uid: 'u_' + email } : null; try { if (email) localStorage.setItem('mock_user', email); else localStorage.removeItem('mock_user'); } catch (e) {} }
  window.OCPR_CLOUD = {
    available: true, toEmail: toEmail, shortName: function (e) { return String(e || '').replace(DOMAIN, ''); },
    init: function (c) { cfg = c; },
    onAuth: function (cb) { authCb = cb; var e = null; try { e = localStorage.getItem('mock_user'); } catch (x) {} setUser(e); setTimeout(function () { cb(user); }, 20); return function () {}; },
    currentUser: function () { return user; },
    signIn: function (id, pw) { return api('login', { email: toEmail(id), pw: pw }).then(function () { setUser(toEmail(id)); setTimeout(function () { authCb(user); }, 10); return user; }); },
    signOut: function () { setUser(null); setTimeout(function () { authCb(null); }, 10); return Promise.resolve(); },
    errorCode: function (e) { return e && e.code; },
    getStaff: function (email) { return api('staff-get', { email: email }).then(function (j) { return j.staff; }); },
    isInitialised: function () { return api('init-get').then(function (j) { return j.init; }); },
    registerFirstAdmin: function (id, pw, name) {
      var email = toEmail(id);
      return api('register', { email: email, pw: pw }).then(function () {
        setUser(email); authCb(user);                       // comme Firebase : la session s'ouvre avant l'écriture du profil
        return new Promise(function (r) { setTimeout(r, 60); }).then(function () { return api('register-admin-doc', { email: email, name: name }); })
          .then(null, function (e) { setUser(null); authCb(null); throw e; });
      });
    },
    listStaff: function () { return api('staff-list').then(function (j) { return j.list; }); },
    addStaff: function (id, pw, name, role) { return api('staff-add', { email: toEmail(id), pw: pw, name: name, role: role }); },
    removeStaff: function (email) { return api('staff-del', { email: email }); },
    watch: function (col, cb, onErr) {
      var known = null, stop = false;
      function tick() {
        if (stop) return;
        if (mock.offline) { if (known === null) { known = {}; cb([], true, { fromCache: true, pending: mock.queue.length > 0 }); } return setTimeout(tick, 250); }
        api('col', { col: col }).then(function (j) {
          var docs = j.docs, changes = [], init = known === null; known = known || {};
          Object.keys(docs).forEach(function (id) {
            var s = JSON.stringify(docs[id]);
            if (known[id] === undefined) changes.push({ type: 'added', id: id, data: docs[id], pending: false });
            else if (known[id] !== s) changes.push({ type: 'modified', id: id, data: docs[id], pending: false });
            known[id] = s;
          });
          Object.keys(known).forEach(function (id) { if (!(id in docs)) { changes.push({ type: 'removed', id: id, data: {}, pending: false }); delete known[id]; } });
          if (init || changes.length) cb(changes, init, { fromCache: false, pending: mock.queue.length > 0, ids: Object.keys(docs) });
          setTimeout(tick, 250);
        }, function (e) { if (onErr && e && e.code === 'permission-denied') onErr(col, e); setTimeout(tick, 500); });
      }
      tick(); return function () { stop = true; };
    },
    watchParams: function (cb, onErr) {
      var last, stop = false, first = true;
      function tick() {
        if (stop) return;
        if (mock.offline) { if (first) { first = false; cb(null, true, { fromCache: true, pending: false }); } return setTimeout(tick, 250); }
        api('params-get').then(function (j) {
          var s = JSON.stringify(j.doc);
          if (first || s !== last) { var i = first; first = false; last = s; cb(j.doc, i, { fromCache: false, pending: false }); }
          setTimeout(tick, 250);
        }, function () { setTimeout(tick, 500); });
      }
      tick(); return function () { stop = true; };
    },
    set: function (col, id, doc) { return write('set', { col: col, id: id, doc: doc }); },
    del: function (col, id) { return write('del', { col: col, id: id }); },
    setParams: function (doc) { return write('params-set', { doc: doc }); }
  };
  function write(path, body) {
    mock.log.push(path + ':' + (body.col || 'params') + ':' + (body.id || ''));
    if (mock.offline) return new Promise(function (res, rej) { mock.queue.push({ path: path, body: body, res: res, rej: rej }); });
    return api(path, body);
  }
  mock.goOnline = function () {
    mock.offline = false; var q = mock.queue; mock.queue = [];
    q.forEach(function (w) { api(w.path, w.body).then(w.res, w.rej); });
  };
  window.OCPR_NATIVE = { isNative: location.hash === '#native', shared: [], shareFile: function (n, d) { this.shared.push(n); return Promise.resolve(true); } };
})();
