import re, sys, json, urllib.request
from playwright.sync_api import sync_playwright
BASE='http://localhost:8790'
XLSX='/tmp/claude-0/-home-claude/70b1240e-3e42-5168-ad79-ff4ea9f582a2/scratchpad/ocpr/employes.xlsx'
CFG='{"apiKey":"AIzaTEST","authDomain":"demo.firebaseapp.com","projectId":"demo-oceanis","appId":"1:123:web:abc"}'
ok=ko=0; errors=[]
def check(n,c,i=''):
    global ok,ko
    if c: ok+=1; print('  ok ',n)
    else: ko+=1; print('ÉCHEC',n,i)
def post(path,body=None):
    r=urllib.request.Request(BASE+'/api/'+path,data=json.dumps(body or {}).encode(),headers={'content-type':'application/json'})
    try: return json.loads(urllib.request.urlopen(r).read())
    except urllib.error.HTTPError as e: return json.loads(e.read())
post('_reset')
with sync_playwright() as p:
    b=p.chromium.launch()
    def phone(name):
        ctx=b.new_context(viewport={'width':390,'height':844},device_scale_factor=2,locale='fr-FR',permissions=[])
        pg=ctx.new_page(); pg.on('pageerror',lambda e:errors.append(name+': '+str(e)))
        pg.on('console',lambda m: errors.append(name+' console: '+m.text) if m.type=='error' and 'ERR_TUNNEL' not in m.text and 'status of 40' not in m.text and 'favicon' not in m.text else None)
        return ctx,pg
    # ---------- admin : premier démarrage ----------
    actx,A=phone('admin'); A.goto(BASE+'/#native'); A.wait_for_selector('text=Bienvenue')
    check('premier lancement : écran de choix', A.locator('text=Utiliser sans serveur').count()==1)
    A.screenshot(path='s1-choix.png')
    A.click('[data-act=cl-config]'); A.wait_for_selector('#cfg-text')
    A.fill('#cfg-text','pas une config'); A.click('#f-cfg button[type=submit]'); A.wait_for_selector('text=Configuration invalide')
    A.fill('#cfg-text',CFG); A.click('#f-cfg button[type=submit]'); A.wait_for_selector('#f-login')
    A.screenshot(path='s2-connexion.png')
    A.click('[data-act=cl-register]'); A.wait_for_selector('#f-register')
    A.fill('#f-register [name=name]','Mahandry'); A.fill('#f-register [name=id]','mahandry@oceanis.test'); A.fill('#f-register [name=pw]','motdepasse1'); A.fill('#f-register [name=pw2]','autre123')
    A.click('#f-register button[type=submit]'); check('mots de passe différents refusés', 'sont différents' in A.inner_text('#cl-err'))
    A.fill('#f-register [name=pw2]','motdepasse1'); A.click('#f-register button[type=submit]')
    A.wait_for_selector('.nav'); A.wait_for_selector('#sync-sub.ok', timeout=8000)
    check('admin connecté, état Synchronisé', 'Synchronisé' in A.inner_text('#sync-sub'))
    check('compte admin créé côté serveur', post('_state')['staff'].get('mahandry@oceanis.test',{}).get('role')=='admin')
    check('pas de flash « non autorisé »', 'non autorisé' not in A.inner_text('body'))
    # ---------- admin : entreprise et cartes ----------
    A.click('text=créer une première entreprise'); A.fill('input[name=name]','Velogic'); A.click('#f-co button[type=submit]'); A.wait_for_selector('h2:has-text("Velogic")')
    A.click('[data-act=import-xl]'); A.wait_for_selector('#xl-file',state='attached'); A.set_input_files('#xl-file',XLSX); A.wait_for_selector('text=Vérifier la liste')
    A.click('#imp-create'); A.wait_for_selector('text=carte(s) créée(s)'); A.wait_for_timeout(1200)
    st=post('_state'); check('entreprise sur le serveur', len(st['docs']['companies'])==1)
    check('6 cartes sur le serveur', len(st['docs']['cards'])==6, len(st['docs']['cards']))
    check('réglages sur le serveur', st['params'] is not None)
    codes=re.findall(r'OCPR-VELOGI-\d{3}-[0-9A-Z]{2}',A.inner_text('main')); check('codes visibles', len(codes)>=6, codes)
    # ---------- admin : équipe ----------
    A.click('[data-act=nav][data-tab=settings]'); A.wait_for_selector('[data-act=cl-team]')
    A.screenshot(path='s3-reglages.png',full_page=True)
    A.click('[data-act=cl-invite]'); A.wait_for_selector('.modal img'); check('QR d’invitation affiché', A.locator('.modal img').count()==1); A.screenshot(path='s4-invite.png'); A.click('.modal [data-act=modal-close]')
    A.click('[data-act=cl-team]'); A.wait_for_selector('#f-staff')
    A.fill('#f-staff [name=name]','Portail principal'); A.fill('#f-staff [name=id]','portail1'); A.fill('#f-staff [name=pw]','secret1'); A.click('#f-staff button[type=submit]')
    A.wait_for_selector('#team-list >> text=Portail principal'); check('gardien créé', 'portail1' in A.inner_text('#team-list'))
    A.fill('#f-staff [name=name]','Doublon'); A.fill('#f-staff [name=id]','portail1'); A.fill('#f-staff [name=pw]','secret2'); A.click('#f-staff button[type=submit]')
    A.wait_for_selector('#cl-err:has-text("existe déjà")'); check('identifiant déjà pris signalé', True)
    A.screenshot(path='s5-equipe.png'); A.click('#f-staff [data-act=modal-close]')
    # ---------- gardien : connexion ----------
    gctx,G=phone('garde'); G.goto(BASE+'/#native'); G.wait_for_selector('[data-act=cl-config]'); G.click('[data-act=cl-config]'); G.fill('#cfg-text',CFG); G.click('#f-cfg button[type=submit]'); G.wait_for_selector('#f-login')
    G.fill('#f-login [name=id]','portail1'); G.fill('#f-login [name=pw]','mauvais'); G.click('#f-login button[type=submit]'); G.wait_for_selector('#cl-err:has-text("incorrect")'); check('mauvais mot de passe refusé', True)
    G.fill('#f-login [name=pw]','secret1'); G.click('#f-login button[type=submit]'); G.wait_for_selector('.nav'); G.wait_for_selector('#sync-sub.ok',timeout=8000)
    nav=G.inner_text('.nav'); check('mode gardien forcé', 'Scanner' in nav and 'Compte' in nav and 'Réglages' not in nav, nav)
    check('pas de bouton pour quitter le mode gardien', G.locator('[data-act=leave-guard],[data-act=enter-guard]').count()==0)
    G.click('[data-act=nav][data-tab=sync]'); G.wait_for_timeout(600)
    check('le gardien a reçu les 6 cartes', '6 carte(s) en mémoire' in G.inner_text('main'), G.inner_text('main')[:300])
    G.screenshot(path='s6-garde-compte.png')
    # ---------- scan et remontée en direct ----------
    def scan(pg,code):
        pg.click('[data-act=nav][data-tab=scan]'); pg.wait_for_selector('#manual'); pg.fill('#manual',code); pg.press('#manual','Enter'); pg.wait_for_selector('[data-act=scan-confirm]'); pg.click('[data-act=scan-confirm]')
    scan(G,codes[0]); G.wait_for_timeout(300)
    A.click('[data-act=nav][data-tab=visits]'); A.wait_for_selector('text=1 passage(s)',timeout=6000); check('passage visible chez l’admin en direct', True)
    A.screenshot(path='s7-admin-passages.png')
    # ---------- réseau coupé ----------
    G.evaluate('window.__mock.offline=true'); gctx.set_offline(True); G.wait_for_timeout(300)
    check('indicateur hors ligne', 'Hors ligne' in G.inner_text('#sync-sub'), G.inner_text('#sync-sub'))
    scan(G,codes[1]); G.wait_for_timeout(600)
    check('hors ligne : le scan fonctionne (2 passages affichés)', G.locator('#recent .row').count()==2, G.locator('#recent .row').count())
    A.wait_for_timeout(800); check('hors ligne : pas encore chez l’admin', 'passage(s)' in A.inner_text('main') and '1 passage(s)' in A.inner_text('main'))
    G.screenshot(path='s8-garde-hors-ligne.png')
    gctx.set_offline(False); G.evaluate('window.__mock.goOnline()'); A.wait_for_selector('text=2 passage(s)',timeout=8000); check('retour du réseau : passage envoyé', True)
    st=post('_state'); check('exactement 2 passages sur le serveur', len(st['docs']['visits'])==2, len(st['docs']['visits']))
    # ---------- redémarrage du gardien sans réseau ----------
    G.evaluate('window.__mock.offline=true'); G.reload(); G.wait_for_selector('.nav',timeout=8000)
    check('redémarrage hors ligne : session et données conservées', G.locator('[data-act=nav][data-tab=scan]').count()==1)
    G.click('[data-act=nav][data-tab=today]'); check('passages du jour visibles hors ligne', G.locator('main .list .row').count()==2, G.locator('main .list .row').count())
    scan(G,codes[2]); G.wait_for_timeout(300)
    G.evaluate('window.__mock.goOnline(); window.__mock.offline=false'); A.wait_for_selector('text=3 passage(s)',timeout=10000); check('passage pris hors ligne après redémarrage envoyé', True)
    check('toujours aucun doublon', len(post('_state')['docs']['visits'])==3)
    # ---------- droits : le gardien ne peut rien modifier d’autre ----------
    r=G.evaluate("fetch('/api/set',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({token:'portail1@oceanis-pass.app',col:'companies',id:'x',doc:{name:'Pirate'}})}).then(r=>r.status)")
    check('serveur refuse l’écriture d’une entreprise par un gardien', r==403, r)
    # ---------- admin : modification propagée au gardien ----------
    A.click('[data-act=nav][data-tab=companies]'); A.click('[data-act=open-company]'); A.wait_for_selector('[data-act-change=company-tier]')
    A.select_option('[data-act-change=company-tier]','gold'); G.wait_for_timeout(1200)
    G.click('[data-act=nav][data-tab=scan]'); G.fill('#manual',codes[3]); G.press('#manual','Enter'); G.wait_for_selector('#result .chip.gold, .chip.gold',timeout=5000); check('palier Gold propagé au poste de garde', True)
    # ---------- déconnexion / compte non autorisé ----------
    A.click('[data-act=nav][data-tab=settings]'); A.click('[data-act=cl-logout]'); A.click('#ask-yes'); A.wait_for_selector('#f-login')
    check('déconnexion → écran de connexion', True)
    post('register',{'email':'intrus@x.test','pw':'123456'})
    A.fill('#f-login [name=id]','intrus@x.test'); A.fill('#f-login [name=pw]','123456'); A.click('#f-login button[type=submit]'); A.wait_for_selector('text=Compte non autorisé'); check('compte sans profil : refusé', True)
    A.click('[data-act=cl-logout-now]'); A.wait_for_selector('#f-login')
    A.fill('#f-login [name=id]','mahandry@oceanis.test'); A.fill('#f-login [name=pw]','motdepasse1'); A.click('#f-login button[type=submit]'); A.wait_for_selector('.nav')
    check('reconnexion admin : données présentes', 'Velogic' in A.inner_text('body') or A.locator('[data-act=nav]').count()>0)
    A.click('[data-act=nav][data-tab=settings]')
    A.click('[data-act=wipe-all]'); A.wait_for_selector('.toast'); check('effacement total refusé en mode synchronisé', 'synchronisé' in A.inner_text('.toast'))
    # ---------- retrait d'un gardien ----------
    A.click('[data-act=cl-team]'); A.wait_for_selector('[data-act=cl-team-del]'); A.click('[data-act=cl-team-del]'); A.click('#ask-yes'); A.wait_for_timeout(600)
    check('gardien retiré côté serveur', 'portail1@oceanis-pass.app' not in post('_state')['staff'])
    b.close()
print('erreurs JS:',errors or 'aucune'); print(ok,'OK',ko,'échec(s)'); sys.exit(1 if ko or errors else 0)
