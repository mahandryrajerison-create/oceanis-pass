// Tests du noyau de synchronisation avec un faux serveur Firestore et plusieurs « téléphones ».
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const SYNC = require('../src/sync-core.js');

/* ---- faux serveur : documents par collection + écouteurs façon onSnapshot ---- */
class Server {
  constructor() { this.docs = {}; this.listeners = []; this.writes = 0; }
  col(c) { return this.docs[c] || (this.docs[c] = {}); }
  reorder(o) { const r = {}; Object.keys(o).sort().reverse().forEach(k => { r[k] = o[k]; }); return r; } // Firestore ne garde pas l'ordre des clés
  set(c, id, data, from) {
    const existed = id in this.col(c);
    this.col(c)[id] = this.reorder(JSON.parse(JSON.stringify(data))); this.writes++;
    this.notify(c, [{ type: existed ? 'modified' : 'added', id, data: this.col(c)[id] }], from);
  }
  del(c, id, from) { if (!(id in this.col(c))) return; delete this.col(c)[id]; this.writes++; this.notify(c, [{ type: 'removed', id, data: {} }], from); }
  notify(c, changes, from) { this.listeners.filter(l => l.col === c && l.dev !== from && l.dev.online).forEach(l => l.cb(changes.map(x => ({ ...x, pending: false })), false)); }
  snapshot(c) { return Object.keys(this.col(c)).map(id => ({ type: 'added', id, data: this.col(c)[id], pending: false })); }
}

/* ---- faux téléphone : état S, base persistée, file d'écritures hors-ligne ---- */
class Phone {
  constructor(server, role, name, saved) {
    this.server = server; this.role = role; this.name = name; this.online = true; this.queue = [];
    this.S = saved ? JSON.parse(JSON.stringify(saved.S)) : { companies: [], cards: [], events: [], visits: [], params: { updatedAt: 0, v: 'défaut' } };
    this.errors = [];
    this.start(saved ? saved.base : null);
  }
  start(base) {
    const self = this;
    this.sync = SYNC.create({
      role: this.role, base: base ? JSON.parse(JSON.stringify(base)) : {},
      backend: {
        set: (c, id, d) => self.write(() => self.server.set(c, id, d, self)),
        del: (c, id) => self.write(() => self.server.del(c, id, self)),
        setParams: d => self.write(() => self.server.set('meta', 'params', d, self))
      },
      onError: e => self.errors.push(e)
    });
    this.sync.cols().forEach(c => { this.server.listeners.push({ col: c, dev: this, cb: (ch, init) => this.remote(c, ch, init) }); });
    this.server.listeners.push({ col: 'meta', dev: this, cb: ch => this.remoteParams(ch) });
    if (this.online) this.attach(); else this.attachCache();
  }
  attachCache() { // hors-ligne : Firestore sert le cache persistant (éléments déjà synchronisés)
    this.sync.cols().forEach(c => {
      const known = (this.sync.base[c] || {});
      this.remote(c, this.S[c].filter(x => known[x.id] !== undefined).map(x => ({ type: 'added', id: x.id, data: x, pending: false })), true, { fromCache: true });
    });
    this.sync.applyRemoteParams(this.S, null, false);
  }
  attach() { // premier snapshot de chaque écouteur
    this.sync.cols().forEach(c => this.remote(c, this.server.snapshot(c), true));
    const p = this.server.col('meta').params;
    this.sync.applyRemoteParams(this.S, p || null, false);
    this.save();
  }
  write(fn) { if (this.online) { fn(); return Promise.resolve(); } this.queue.push(fn); return new Promise(() => {}); }
  remote(c, ch, init, opts) { this.sync.applyRemote(this.S, c, ch, init, opts || { ids: init ? ch.map(x => x.id) : undefined }); }
  remoteParams(ch) { const d = ch.find(x => x.id === 'params'); if (d) this.sync.applyRemoteParams(this.S, d.data, false); }
  save() { return this.sync.push(this.S); }
  goOffline() { this.online = false; }
  goOnline() { // Firestore rejoue la file puis renvoie l'état serveur
    this.online = true; this.save();
    const q = this.queue; this.queue = []; q.forEach(f => f());
    this.sync.cols().forEach(c => this.remote(c, this.server.snapshot(c), false));
  }
  persist() { return { S: JSON.parse(JSON.stringify(this.S)), base: JSON.parse(JSON.stringify(this.sync.base)) }; }
  restart(online = true) { // fermeture et réouverture de l'application
    const saved = this.persist();
    this.server.listeners = this.server.listeners.filter(l => l.dev !== this);
    this.online = online; this.queue = [];
    this.S = JSON.parse(JSON.stringify(saved.S)); this.start(saved.base);
    if (online) this.attach();
  }
}

const company = (id, name) => ({ id, name, code: id.toUpperCase(), tier: 'terre', status: 'active', tierLog: [{ ts: 1, to: 'terre' }], updatedAt: 1 });
const card = (id, co, holder) => ({ id, companyId: co, holder, status: 'active', updatedAt: 1 });
const visit = (id, cardId, net) => ({ id, cardId, net, ts: Date.now(), void: false });
let n = 0; const t = (name, fn) => { fn(); n++; console.log('  ok  ' + name); };

t('un admin crée des données, un gardien qui rejoint les reçoit', () => {
  const s = new Server(); const a = new Phone(s, 'admin', 'A');
  a.S.companies.push(company('c1', 'Telma')); a.S.cards.push(card('k1', 'c1', 'Rakoto'), card('k2', 'c1', 'Rabe'));
  assert.equal(a.save(), 3);
  const g = new Phone(s, 'garde', 'G');
  assert.equal(g.S.companies.length, 1); assert.equal(g.S.cards.length, 2);
  assert.equal(g.S.events.length, 0, 'le gardien ne reçoit pas les événements');
});

t('le gardien envoie ses passages, l’admin les reçoit en direct', () => {
  const s = new Server(); const a = new Phone(s, 'admin', 'A'); const g = new Phone(s, 'garde', 'G');
  a.S.companies.push(company('c1', 'Telma')); a.save();
  g.S.visits.push(visit('v1', 'k1', 4500)); assert.equal(g.save(), 1);
  assert.equal(a.S.visits.length, 1); assert.equal(a.S.visits[0].net, 4500);
});

t('un gardien ne peut pas écrire entreprises, cartes ni réglages', () => {
  const s = new Server(); const g = new Phone(s, 'garde', 'G');
  g.S.companies.push(company('cX', 'Intrus')); g.S.cards.push(card('kX', 'cX', 'x')); g.S.params.v = 'piraté';
  assert.equal(g.save(), 0); assert.equal(s.writes, 0);
});

t('pas d’écho : après réception, rien n’est renvoyé', () => {
  const s = new Server(); const a = new Phone(s, 'admin', 'A'); const b = new Phone(s, 'admin', 'B');
  a.S.companies.push(company('c1', 'Telma')); a.save();
  const w = s.writes; assert.equal(b.save(), 0); assert.equal(s.writes, w);
});

t('l’ordre des champs renvoyé par le serveur ne provoque aucune réécriture', () => {
  const s = new Server(); const a = new Phone(s, 'admin', 'A');
  a.S.companies.push(company('c1', 'Telma')); a.save(); a.restart();
  assert.equal(a.save(), 0);
});

t('hors-ligne : les passages sont mis en file puis envoyés une seule fois', () => {
  const s = new Server(); const a = new Phone(s, 'admin', 'A'); const g = new Phone(s, 'garde', 'G');
  g.goOffline();
  g.S.visits.push(visit('v1', 'k1', 100), visit('v2', 'k1', 200)); g.save();
  assert.equal(a.S.visits.length, 0);
  g.goOnline();
  assert.equal(a.S.visits.length, 2); assert.equal(Object.keys(s.col('visits')).length, 2);
  g.save(); assert.equal(Object.keys(s.col('visits')).length, 2);
});

t('redémarrage hors-ligne puis retour du réseau : rien de perdu, pas de doublon', () => {
  const s = new Server(); const a = new Phone(s, 'admin', 'A'); const g = new Phone(s, 'garde', 'G');
  a.S.companies.push(company('c1', 'Telma')); a.save();
  g.restart(true);
  g.restart(false);                        // l'appli est rouverte sans réseau
  g.S.visits.push(visit('v9', 'k1', 900)); g.save();
  assert.equal(g.S.companies.length, 1, 'le cache local reste utilisable hors-ligne');
  g.goOnline();
  assert.equal(s.col('visits').v9.net, 900);
  assert.equal(Object.keys(s.col('visits')).length, 1);
});

t('deux admins modifient des entreprises différentes : tout converge', () => {
  const s = new Server(); const a = new Phone(s, 'admin', 'A'); const b = new Phone(s, 'admin', 'B');
  a.S.companies.push(company('c1', 'Telma'), company('c2', 'Orange')); a.save();
  a.S.companies[0].tier = 'gold'; a.save();
  b.S.companies.find(c => c.id === 'c2').tier = 'premium'; b.save();
  assert.equal(a.S.companies.find(c => c.id === 'c2').tier, 'premium');
  assert.equal(b.S.companies.find(c => c.id === 'c1').tier, 'gold');
});

t('une suppression se propage, y compris à un téléphone absent pendant ce temps', () => {
  const s = new Server(); const a = new Phone(s, 'admin', 'A'); const b = new Phone(s, 'admin', 'B');
  a.S.visits.push(visit('v1', 'k', 1), visit('v2', 'k', 2)); a.save();
  assert.equal(b.S.visits.length, 2);
  b.goOffline();
  a.S.visits = a.S.visits.filter(v => v.id !== 'v1'); a.save();
  assert.equal(b.S.visits.length, 2);
  b.restart(true);                          // B rouvre l'appli avec le réseau
  assert.deepEqual(b.S.visits.map(v => v.id), ['v2']);
});

t('un téléphone qui avait déjà des données locales les envoie à la première connexion', () => {
  const s = new Server(); const a = new Phone(s, 'admin', 'A');
  a.S.companies.push(company('c1', 'Ancienne donnée')); a.S.cards.push(card('k1', 'c1', 'Rakoto'));
  assert.equal(a.save(), 2, 'envoyé dès que la collection est prête');
  assert.equal(Object.keys(s.col('companies')).length, 1);
});

t('une modification locale non envoyée n’est pas écrasée par un changement distant', () => {
  const s = new Server(); const a = new Phone(s, 'admin', 'A'); const b = new Phone(s, 'admin', 'B');
  a.S.companies.push(company('c1', 'Telma')); a.save();
  b.S.companies[0].name = 'Telma SA';                 // pas encore sauvegardé
  s.set('companies', 'c1', { ...s.col('companies').c1, notes: 'vu par A' }, a); // arrive côté B
  assert.equal(b.S.companies[0].name, 'Telma SA');
  b.save(); assert.equal(s.col('companies').c1.name, 'Telma SA');
});

t('réglages : l’admin les change, le gardien les reçoit ; le gardien ne peut pas les changer', () => {
  const s = new Server(); const a = new Phone(s, 'admin', 'A'); const g = new Phone(s, 'garde', 'G');
  a.S.params = { updatedAt: 5, v: 'nouveau' }; a.save();
  assert.equal(g.S.params.v, 'nouveau');
  g.S.params.v = 'piraté'; g.save(); assert.equal(s.col('meta').params.v, 'nouveau');
});

t('un gardien partage les passages d’un autre gardien sans les renvoyer', () => {
  const s = new Server(); const g1 = new Phone(s, 'garde', 'G1'); const g2 = new Phone(s, 'garde', 'G2');
  g1.S.visits.push(visit('v1', 'k', 1)); g1.save();
  assert.equal(g2.S.visits.length, 1); const w = s.writes; assert.equal(g2.save(), 0); assert.equal(s.writes, w);
});

t('un cache hors-ligne vide ne supprime rien ; le premier vrai envoi du serveur reconcilie', () => {
  const s = new Server(); const a = new Phone(s, 'admin', 'A');
  a.S.visits.push(visit('v1', 'k', 1), visit('v2', 'k', 2)); a.save();
  const saved = a.persist();
  s.del('visits', 'v1');                                   // supprimé ailleurs pendant l'absence
  a.S = JSON.parse(JSON.stringify(saved.S));
  a.sync = SYNC.create({ role: 'admin', base: saved.base, backend: { set() {}, del() {}, setParams() {} } });
  a.sync.applyRemote(a.S, 'visits', [], true, { fromCache: true });          // cache vide hors-ligne
  assert.equal(a.S.visits.length, 2, 'rien supprimé à partir d’un cache');
  a.sync.applyRemote(a.S, 'visits', [], false, { ids: ['v2'] });             // le serveur répond : v1 n'existe plus
  assert.deepEqual(a.S.visits.map(v => v.id), ['v2']);
});

// rejet du serveur (droits) : l'erreur est signalée et l'élément sera réessayé à la sauvegarde suivante
{
  const errs = []; let attempts = 0;
  const sync = SYNC.create({ role: 'garde', base: {}, backend: { set: () => { attempts++; return Promise.reject(new Error('permission-denied')); }, del() {}, setParams() {} }, onError: e => errs.push(e.message) });
  sync.readyCols.visits = true;
  const S = { visits: [visit('v1', 'k', 1)] };
  sync.push(S);
  await new Promise(r => setTimeout(r, 5));
  assert.deepEqual(errs, ['permission-denied']);
  sync.push(S); assert.equal(attempts, 2, 'réessayé');
  n++; console.log('  ok  un rejet du serveur est signalé puis réessayé');
}
console.log(n + ' tests réussis');
