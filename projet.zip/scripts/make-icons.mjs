// Génère les icônes PNG à partir de assets/icon.svg (sharp est fourni avec @capacitor/assets).
import sharp from 'sharp';
const svg = 'assets/icon.svg';
await sharp(svg).resize(1024, 1024).png().toFile('assets/icon-only.png');
await sharp(svg).resize(1024, 1024).png().toFile('assets/icon-foreground.png');
await sharp({ create: { width: 1024, height: 1024, channels: 3, background: '#0E2A66' } }).png().toFile('assets/icon-background.png');
console.log('icônes générées');
