// Ajoute l'autorisation caméra (scan des cartes) au projet Android généré par Capacitor.
import fs from 'node:fs';
const p = 'android/app/src/main/AndroidManifest.xml';
let s = fs.readFileSync(p, 'utf8');
if (!s.includes('android.permission.CAMERA')) {
  s = s.replace('<uses-permission android:name="android.permission.INTERNET" />',
    '<uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />');
  if (!s.includes('android.permission.CAMERA')) throw new Error('Manifest : repère INTERNET introuvable');
  fs.writeFileSync(p, s);
}
console.log('manifest OK');
