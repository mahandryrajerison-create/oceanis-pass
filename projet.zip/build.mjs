// Assemble www/ : interface (app-base.html + ui-cloud.js) + bundle Firebase/Capacitor (esbuild).
import fs from 'node:fs';
import path from 'node:path';
import { build } from 'esbuild';

const root = path.dirname(new URL(import.meta.url).pathname);
const out = path.join(root, 'www');
fs.mkdirSync(out, { recursive: true });

await build({
  entryPoints: [path.join(root, 'src/entry.js')],
  bundle: true, minify: true, format: 'iife', target: ['chrome100'],
  outfile: path.join(out, 'cloud.bundle.js'), legalComments: 'none', logLevel: 'info'
});

let html = fs.readFileSync(path.join(root, 'src/app-template.html'), 'utf8');
const ui = fs.readFileSync(path.join(root, 'src/ui-cloud.js'), 'utf8');
const patch = await import('./src/patch-app.mjs');
html = patch.default(html, ui);
// bibliothèques tierces : prises dans node_modules (pas stockées dans le dépôt)
const libs = {
  qrcode: 'node_modules/qrcode-generator/dist/qrcode.js',
  jsqr: 'node_modules/jsqr/dist/jsQR.js',
  xlsx: 'node_modules/xlsx/dist/xlsx.mini.min.js'
};
for (const [k, f] of Object.entries(libs)) {
  const code = fs.readFileSync(path.join(root, f), 'utf8').replace(/<\/script/gi, '<\\/script');
  html = html.replace('<!--LIB:' + k + '-->', () => '<script>\n' + code + '\n</script>');
}
fs.writeFileSync(path.join(out, 'index.html'), html);
console.log('www/index.html', (html.length / 1024).toFixed(0) + ' Ko');
