/* Noyau de synchronisation — Oceanis Corporate Pass-Rewards
   Fonctions pures, sans dépendance à Firebase ni au navigateur : testées sous node.
   Le « backend » (Firestore) est injecté ; ce module décide quoi envoyer et quoi appliquer.

   Principe : l'application garde son état S en mémoire (comme avant). Après chaque
   sauvegarde, push() compare S avec la dernière version connue du serveur (« base »)
   et n'envoie que ce qui a changé. Les changements distants sont appliqués par applyRemote().
   La base est un dictionnaire { collection: { id: empreinte } } conservé sur l'appareil. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.OCPR_SYNC = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* Droits par rôle : miroir de firestore.rules (le serveur fait foi). */
  var ACCESS = {
    admin: { read: ['companies', 'cards', 'events', 'visits'], write: ['companies', 'cards', 'events', 'visits'], params: true, del: true },
    garde: { read: ['companies', 'cards', 'visits'], write: ['visits'], params: false, del: false }
  };

  /* JSON à clés triées : deux objets identiques donnent la même chaîne, quel que soit l'ordre des champs
     (Firestore ne conserve pas l'ordre des clés). */
  function stable(v) {
    if (v === null || v === undefined) return 'null';
    if (typeof v !== 'object') return JSON.stringify(v);
    if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
    return '{' + Object.keys(v).filter(function (k) { return v[k] !== undefined; }).sort().map(function (k) { return JSON.stringify(k) + ':' + stable(v[k]); }).join(',') + '}';
  }
  /* Empreinte 53 bits (cyrb53) : garde la base légère sur l'appareil. */
  function hash(str) {
    var h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (var i = 0, ch; i < str.length; i++) {
      ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
  }
  function fp(v) { return hash(stable(v)); }
  /* Copie profonde sans les valeurs undefined (refusées par Firestore). */
  function clean(v) { return JSON.parse(JSON.stringify(v)); }

  function create(opts) {
    var acc = ACCESS[opts.role];
    if (!acc) throw new Error('Rôle inconnu : ' + opts.role);
    var base = opts.base || {};
    var backend = opts.backend;
    var ready = {}, reconciled = {};
    var self = {
      role: opts.role,
      base: base,
      readyCols: ready,
      cols: function () { return acc.read.slice(); },
      canParams: acc.params,
      isReady: function () { return acc.read.every(function (c) { return ready[c]; }) && ready.params === true; }
    };
    function baseOf(col) { return base[col] || (base[col] = {}); }

    /* Envoie au serveur tout ce qui a changé depuis la dernière synchronisation.
       Ne pousse une collection qu'une fois son état initial reçu (sinon on risquerait
       d'écraser des données plus récentes avec une copie ancienne). */
    self.push = function (S) {
      var n = 0;
      acc.write.forEach(function (col) {
        if (!ready[col]) return;
        var b = baseOf(col), seen = {};
        (S[col] || []).forEach(function (item) {
          if (!item || !item.id) return;
          seen[item.id] = true;
          var doc = clean(item), h = fp(doc);
          if (b[item.id] === h) return;
          b[item.id] = h; n++;
          run(backend.set(col, item.id, doc), function (err) { if (b[item.id] === h) delete b[item.id]; fail(err, col, item.id); });
        });
        if (acc.del) Object.keys(b).forEach(function (id) {
          if (seen[id]) return;
          var old = b[id]; delete b[id]; n++;
          run(backend.del(col, id), function (err) { b[id] = old; fail(err, col, id); });
        });
      });
      if (acc.params && ready.params && S.params) {
        var ph = fp(clean(S.params));
        if (base.params !== ph) {
          base.params = ph; n++;
          run(backend.setParams(clean(S.params)), function (err) { if (base.params === ph) delete base.params; fail(err, 'meta', 'params'); });
        }
      }
      return n;
    };
    function run(p, onErr) { if (p && typeof p.then === 'function') p.then(null, onErr); }
    function fail(err, col, id) { if (opts.onError) opts.onError(err, col, id); }

    /* Applique les changements reçus du serveur pour une collection.
       changes : [{ type: 'added'|'modified'|'removed', id, data, pending }]
       initial : true pour le tout premier envoi de cette collection.
       opts    : { ids, fromCache } — ids = liste complète des documents du serveur (pour repérer les suppressions),
                 fromCache = true si l'envoi vient du cache de l'appareil (hors-ligne) et non du serveur.
       Retourne true si S a changé. */
    self.applyRemote = function (S, col, changes, initial, opts) {
      opts = opts || {};
      var b = baseOf(col), arr = S[col] || (S[col] = []), idx = {}, changed = false, remote = {};
      arr.forEach(function (x, i) { idx[x.id] = i; });
      changes.forEach(function (ch) {
        var id = ch.id;
        if (ch.type === 'removed') {
          if (idx[id] !== undefined) { arr[idx[id]] = null; changed = true; }
          delete b[id];
          return;
        }
        remote[id] = true;
        var doc = clean(ch.data || {}); doc.id = id;
        var h = fp(doc), i = idx[id];
        if (ch.pending) return;                       // écriture locale en attente : l'état local fait foi
        if (i !== undefined && arr[i]) {
          var lh = fp(arr[i]);
          if (lh === h) { b[id] = h; return; }
          if (b[id] !== undefined && lh !== b[id]) return;   // modification locale pas encore envoyée : elle gagne
          arr[i] = doc; changed = true;
        } else {
          arr.push(doc); idx[id] = arr.length - 1; changed = true;
        }
        b[id] = h;
      });
      /* Suppressions faites ailleurs pendant notre absence : éléments déjà synchronisés autrefois mais absents
         de la liste complète du serveur. On ne conclut JAMAIS à partir d'un cache hors-ligne (il peut être vide ou
         incomplet) : on attend le premier envoi réel du serveur. Les éléments jamais synchronisés sont conservés. */
      if (!opts.fromCache && !reconciled[col] && (opts.ids || initial)) {
        var known = remote;
        if (opts.ids) { known = {}; opts.ids.forEach(function (id) { known[id] = true; }); }
        arr.forEach(function (x, i) {
          if (x && b[x.id] !== undefined && !known[x.id]) { arr[i] = null; delete b[x.id]; changed = true; }
        });
        reconciled[col] = true;
      }
      if (initial) ready[col] = true;
      if (changed) S[col] = arr.filter(function (x) { return x !== null; });
      return changed;
    };

    /* Réglages (document unique). doc = null si le serveur n'en a pas encore. */
    self.applyRemoteParams = function (S, doc, pending) {
      ready.params = true;
      if (!doc || pending) return false;
      doc = clean(doc);
      var h = fp(doc), local = S.params, lh = local ? fp(local) : null;
      if (lh === h) { base.params = h; return false; }
      if (local) {
        if (base.params !== undefined && lh !== base.params) return false;                   // modif locale en attente
        if (base.params === undefined && (local.updatedAt || 0) > (doc.updatedAt || 0)) return false; // local plus récent, jamais synchronisé
      }
      S.params = doc; base.params = h;
      return true;
    };

    return self;
  }

  return { create: create, stable: stable, fp: fp, hash: hash, ACCESS: ACCESS };
});
