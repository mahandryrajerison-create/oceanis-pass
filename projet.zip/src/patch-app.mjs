// Branche la synchronisation dans l'interface existante (remplacements exacts : échec bruyant si le code de base change).
function rep(s, from, to, label) {
  const i = s.indexOf(from);
  if (i === -1) throw new Error('Repère introuvable : ' + label);
  if (s.indexOf(from, i + 1) !== -1) throw new Error('Repère ambigu : ' + label);
  return s.slice(0, i) + to + s.slice(i + from.length);
}
export default function patch(h, ui) {
  // 1. script du bundle avant l'interface
  h = rep(h, '<!--LIB:xlsx-->\n<script>\n  /* Oceanis Corporate Pass-Rewards — interface */',
    '<!--LIB:xlsx-->\n<script src="cloud.bundle.js"></script>\n<script>\n  /* Oceanis Corporate Pass-Rewards — interface */', 'script bundle');

  // 2. styles
  h = rep(h, '</style>', `
input[type=password]{width:100%;background:var(--surface-2);border:1px solid var(--line);border-radius:10px;padding:10px 12px;min-height:44px;color:var(--ink)}
.gate{max-width:460px;margin:0 auto;padding-top:8px}
.sync{display:inline-flex;align-items:center;gap:5px}
.sync i{display:inline-block;width:8px;height:8px;border-radius:50%;background:#9aa4b8;flex:none}
.sync.ok i{background:#3CC79A}.sync.off i{background:#E2B84E}.sync.err i{background:#E0805A}.sync.wait i{background:#9DB4E8}
.top .sync{font-size:12px}
@media(prefers-reduced-motion:no-preference){.sync.wait i{animation:syncp 1.2s ease-in-out infinite}@keyframes syncp{50%{opacity:.35}}}
</style>`, 'css');

  // 3. enregistrement : envoi au serveur après la sauvegarde locale
  h = rep(h, `    saveTimer = setTimeout(function () {
      idbSet('state', S).catch(function () {`, `    saveTimer = setTimeout(function () {
      cloudPush();
      idbSet('state', S).catch(function () {`, 'save');

  // 4. bloc synchronisation, avant la section fichiers
  h = rep(h, '  /* ---------- fichiers ---------- */', ui + '\n  /* ---------- fichiers ---------- */', 'insertion ui');

  // 5. fichiers : partage natif Android
  h = rep(h, `  function saveFile(filename, data, mime) {
    if (!dl) {`, `  function saveFile(filename, data, mime) {
    if (!dl && window.OCPR_NATIVE && window.OCPR_NATIVE.isNative) {
      return window.OCPR_NATIVE.shareFile(filename, data).catch(function () { toast('Enregistrement impossible.'); return false; });
    }
    if (!dl) {`, 'saveFile');
  h = rep(h, `        var file = new File([blob], name, { type: 'image/png' });`, `        if (window.OCPR_NATIVE && window.OCPR_NATIVE.isNative) return window.OCPR_NATIVE.shareFile(name, blob, 'Pass Oceanis Park').catch(function () { toast('Partage impossible.'); });
        var file = new File([blob], name, { type: 'image/png' });`, 'cardFile');

  // 6. fermeture d'une fenêtre : rattraper les mises à jour reçues entre-temps
  h = rep(h, `  function closeModal() { var m = $('#modal'); if (m) m.remove(); }`,
    `  function closeModal() { var m = $('#modal'); if (m) m.remove(); if (CL.dirty) { CL.dirty = false; remoteRefresh(); } }`, 'closeModal');

  // 7. rendu : écran de connexion, indicateur, rôle gardien
  h = rep(h, `  function render() {
    if (UI.tab !== 'scan') stopCam();`, `  function render() {
    if (CL.screen !== 'config') cfgScanStop();
    if (CL.screen) { stopCam(); $app.innerHTML = viewGate(); return; }
    if (UI.tab !== 'scan') stopCam();`, 'render');
  h = rep(h, `? navBtn('scan', 'Scanner') + navBtn('today', 'Aujourd’hui') + navBtn('sync', 'Fichiers')`,
    `? navBtn('scan', 'Scanner') + navBtn('today', 'Aujourd’hui') + navBtn('sync', cloudOn() ? 'Compte' : 'Fichiers')`, 'nav garde');
  h = rep(h, `<span>Oceanis Park · ' + (guard ? 'poste de garde' : 'gestion') + '</span></div></div>' +
      (guard ? '<button class="pill-btn" data-act="leave-guard">Quitter</button>' : '<button class="pill-btn" data-act="enter-guard">Mode gardien</button>') +`,
    `<span>' + (syncSub() ? '' : 'Oceanis Park · ') + (guard ? 'poste de garde' : 'gestion') + syncSub() + '</span></div></div>' +
      (CL.role === 'garde' ? '' : guard ? '<button class="pill-btn" data-act="leave-guard">Quitter</button>' : '<button class="pill-btn" data-act="enter-guard">Mode gardien</button>') +`, 'shell');

  // 8. onglet Compte du gardien, carte de synchronisation des réglages
  h = rep(h, '  function viewGuardSync() {', '  function viewGuardSync() { return cloudOn() ? viewGuardAccount() : viewGuardFiles(); }\n  function viewGuardFiles() {', 'viewGuardSync');
  h = rep(h, `'<div class="card"><h3>Synchronisation avec les postes de garde</h3>`,
    `cloudCard() + '<div class="card"><h3>' + (cloudOn() ? 'Secours par fichiers' : 'Synchronisation avec les postes de garde') + '</h3>`, 'settings');

  // 9. sécurités en mode synchronisé
  h = rep(h, `'wipe-all': function () { ask(`, `'wipe-all': function () { if (cloudOn()) { toast('Impossible : ce téléphone est synchronisé, l’effacement supprimerait les données de tous les postes.'); return; } ask(`, 'wipe');
  h = rep(h, `'Toutes les données actuelles de cet appareil seront remplacées par celles de la sauvegarde.'`,
    `'Toutes les données actuelles de cet appareil seront remplacées par celles de la sauvegarde.' + (cloudOn() ? ' Le serveur sera aussi remplacé : tous les postes verront ces données.' : '')`, 'restore');

  // 10. actions
  h = rep(h, `  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-act]');`, `  Object.assign(H, CLH);
  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-act]');`, 'handlers');

  // 11. démarrage
  h = rep(h, `    UI.period = C.periods(Date.now())[0].id;
    render();`, `    UI.period = C.periods(Date.now())[0].id;
    render();
    initCloud();`, 'boot');
  return h;
}
