/* Point d'entrée du bundle : Firebase (comptes + Firestore hors-ligne) et fonctions natives Android.
   L'interface (index.html) y accède via window.OCPR_CLOUD, window.OCPR_SYNC et window.OCPR_NATIVE. */
import SYNC from './sync-core.js';
import { initializeApp, deleteApp } from 'firebase/app';
import {
  initializeAuth, indexedDBLocalPersistence, inMemoryPersistence, onAuthStateChanged,
  signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, deleteUser
} from 'firebase/auth';
import {
  initializeFirestore, persistentLocalCache, persistentSingleTabManager, collection, doc,
  setDoc, deleteDoc, getDoc, getDocs, onSnapshot, writeBatch
} from 'firebase/firestore';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

window.OCPR_SYNC = SYNC;

/* ---------------- Firebase ---------------- */
var DOMAIN = '@oceanis-pass.app';
var app = null, auth = null, db = null, cfgKey = '';

function toEmail(id) {
  id = String(id || '').trim().toLowerCase();
  if (id.indexOf('@') !== -1) return id;
  return id.replace(/[^a-z0-9._-]+/g, '') + DOMAIN;
}
function shortName(email) { return String(email || '').replace(DOMAIN, ''); }

function init(cfg) {
  var key = JSON.stringify(cfg);
  if (app && key === cfgKey) return;
  cfgKey = key;
  app = initializeApp({
    apiKey: cfg.apiKey, authDomain: cfg.authDomain, projectId: cfg.projectId,
    storageBucket: cfg.storageBucket, messagingSenderId: cfg.messagingSenderId, appId: cfg.appId
  }, 'ocpr');
  auth = initializeAuth(app, { persistence: indexedDBLocalPersistence });
  db = initializeFirestore(app, { localCache: persistentLocalCache({ tabManager: persistentSingleTabManager() }) });
}

function code(e) { var c = (e && e.code) || ''; return c.replace('auth/', '').replace('permission-denied', 'refus'); }

var CLOUD = {
  available: true,
  toEmail: toEmail,
  shortName: shortName,
  init: init,
  onAuth: function (cb) { return onAuthStateChanged(auth, cb); },
  currentUser: function () { return auth && auth.currentUser; },
  signIn: function (id, pw) { return signInWithEmailAndPassword(auth, toEmail(id), pw).then(function (c) { return c.user; }); },
  signOut: function () { return signOut(auth); },
  errorCode: code,

  /* Statut du compte : { role, name } ou null si l'utilisateur n'est pas dans l'équipe. */
  getStaff: function (email) {
    return getDoc(doc(db, 'staff', email)).then(function (s) { return s.exists() ? s.data() : null; });
  },
  /* Le tout premier administrateur n'existe-t-il pas encore ? */
  isInitialised: function () {
    return getDoc(doc(db, 'meta', 'init')).then(function (s) { return s.exists(); });
  },
  /* Crée le compte administrateur initial (une seule fois par projet Firebase). */
  registerFirstAdmin: function (id, pw, name) {
    var email = toEmail(id);
    return createUserWithEmailAndPassword(auth, email, pw).then(function (cred) {
      var b = writeBatch(db);
      b.set(doc(db, 'staff', email), { role: 'admin', name: name || shortName(email), createdAt: Date.now() });
      b.set(doc(db, 'meta', 'init'), { at: Date.now(), by: email });
      return b.commit().then(function () { return cred.user; }, function (err) {
        return deleteUser(cred.user).then(function () { throw err; }, function () { throw err; });
      });
    });
  },
  listStaff: function () {
    return getDocs(collection(db, 'staff')).then(function (snap) {
      return snap.docs.map(function (d) { return Object.assign({ email: d.id }, d.data()); });
    });
  },
  /* Crée un compte (gardien ou admin) sans déconnecter l'admin : application Firebase secondaire. */
  addStaff: function (id, pw, name, role) {
    var email = toEmail(id);
    var sec = initializeApp(JSON.parse(cfgKey), 'staff-' + Date.now());
    var secAuth = initializeAuth(sec, { persistence: inMemoryPersistence });
    return createUserWithEmailAndPassword(secAuth, email, pw)
      .then(function () { return signOut(secAuth); })
      .then(function () { return setDoc(doc(db, 'staff', email), { role: role === 'admin' ? 'admin' : 'garde', name: name || shortName(email), createdAt: Date.now() }); })
      .then(function () { return deleteApp(sec); }, function (err) { return deleteApp(sec).then(function () { throw err; }, function () { throw err; }); });
  },
  removeStaff: function (email) { return deleteDoc(doc(db, 'staff', email)); },

  /* Écoute une collection : cb(changes, initial, meta). includeMetadataChanges pour savoir quand les écritures sont confirmées. */
  watch: function (col, cb, onErr) {
    var first = true;
    return onSnapshot(collection(db, col), { includeMetadataChanges: true }, function (snap) {
      var changes = snap.docChanges().map(function (c) {
        return { type: c.type, id: c.doc.id, data: c.doc.data(), pending: c.doc.metadata.hasPendingWrites };
      });
      var initial = first; first = false;
      cb(changes, initial, {
        fromCache: snap.metadata.fromCache, pending: snap.metadata.hasPendingWrites,
        ids: snap.metadata.fromCache ? null : snap.docs.map(function (d) { return d.id; })
      });
    }, function (err) { if (onErr) onErr(col, err); });
  },
  watchParams: function (cb, onErr) {
    var first = true;
    return onSnapshot(doc(db, 'meta', 'params'), { includeMetadataChanges: true }, function (snap) {
      var initial = first; first = false;
      cb(snap.exists() ? snap.data() : null, initial, { fromCache: snap.metadata.fromCache, pending: snap.metadata.hasPendingWrites });
    }, function (err) { if (onErr) onErr('params', err); });
  },
  set: function (col, id, data) { return setDoc(doc(db, col, id), data); },
  del: function (col, id) { return deleteDoc(doc(db, col, id)); },
  setParams: function (data) { return setDoc(doc(db, 'meta', 'params'), data); }
};
window.OCPR_CLOUD = CLOUD;

/* ---------------- Android natif : enregistrer / partager un fichier ---------------- */
function blobToBase64(blob) {
  return new Promise(function (res, rej) {
    var fr = new FileReader();
    fr.onload = function () { res(String(fr.result).split(',')[1] || ''); };
    fr.onerror = function () { rej(fr.error); };
    fr.readAsDataURL(blob);
  });
}
window.OCPR_NATIVE = {
  isNative: Capacitor.isNativePlatform(),
  /* Écrit le fichier dans le cache de l'application puis ouvre la feuille de partage Android
     (WhatsApp, e-mail, Drive, « Enregistrer sur l'appareil »…). */
  shareFile: function (filename, data, title) {
    var write = typeof data === 'string'
      ? Promise.resolve({ data: data, encoding: Encoding.UTF8 })
      : blobToBase64(data).then(function (b64) { return { data: b64 }; });
    return write.then(function (w) {
      return Filesystem.writeFile({ path: filename, data: w.data, encoding: w.encoding, directory: Directory.Cache, recursive: true });
    }).then(function (r) {
      return Share.share({ title: title || filename, dialogTitle: 'Enregistrer ou envoyer', files: [r.uri] });
    }).then(function () { return true; }, function (e) {
      if (e && /cancel/i.test(String(e.message || e))) return false;
      throw e;
    });
  }
};
