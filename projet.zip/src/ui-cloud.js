  /* ---------- synchronisation multi-postes (Firebase) ---------- */
  var CL = { cfg: null, user: null, role: null, name: '', screen: null, sync: null, unsubs: [], pend: {}, online: navigator.onLine !== false,
             lastSync: 0, err: '', msg: '', busy: false, registering: false, firstRun: false, dirty: false };
  var CLOUD = window.OCPR_CLOUD || null, SYNCLIB = window.OCPR_SYNC || null;
  var cfgCam = { stream: null, on: false, timer: null };
  function cloudOn() { return !!(CL.cfg && CL.role); }
  function roleLabel() { return CL.role === 'admin' ? 'Administrateur' : 'Poste de garde'; }

  /* petit stockage clé/valeur (IndexedDB, repli localStorage) */
  function kvGet(k) { return idbGet(k).catch(function () { try { var s = localStorage.getItem('ocpr_' + k); return s ? JSON.parse(s) : undefined; } catch (e) { return undefined; } }); }
  function kvSet(k, v) { return idbSet(k, v).catch(function () { try { localStorage.setItem('ocpr_' + k, JSON.stringify(v)); } catch (e) {} }); }

  /* configuration Firebase : JSON, extrait collé depuis la console Firebase, ou contenu d'un QR d'invitation */
  var CFG_KEYS = ['apiKey', 'authDomain', 'projectId', 'storageBucket', 'messagingSenderId', 'appId'];
  function parseConfig(txt) {
    txt = String(txt || '').trim();
    var m = /^OCPRCFG:([\s\S]*)$/.exec(txt); if (m) txt = m[1];
    var cfg = {};
    try { var j = JSON.parse(txt); if (j && typeof j === 'object') cfg = j; } catch (e) {}
    if (!cfg.apiKey) CFG_KEYS.forEach(function (k) { var r = new RegExp('["\']?' + k + '["\']?\\s*:\\s*["\']([^"\']+)["\']').exec(txt); if (r) cfg[k] = r[1]; });
    if (!cfg.apiKey || !cfg.projectId || !cfg.appId) return null;
    var out = {}; CFG_KEYS.forEach(function (k) { if (cfg[k]) out[k] = String(cfg[k]); });
    if (!out.authDomain) out.authDomain = out.projectId + '.firebaseapp.com';
    return out;
  }
  function authMsg(err) {
    var c = (err && (err.code || err.message)) || '';
    if (/invalid-credential|wrong-password|user-not-found|invalid-login/.test(c)) return 'Identifiant ou mot de passe incorrect.';
    if (/too-many-requests/.test(c)) return 'Trop d’essais. Patientez quelques minutes.';
    if (/network|unavailable/.test(c)) return 'Pas de réseau. La première connexion d’un téléphone demande Internet.';
    if (/email-already-in-use/.test(c)) return 'Cet identifiant existe déjà : choisissez-en un autre (ex. portail2).';
    if (/weak-password/.test(c)) return 'Mot de passe trop court (6 caractères minimum).';
    if (/invalid-email/.test(c)) return 'Identifiant invalide (lettres, chiffres, point, tiret).';
    if (/permission-denied|refus/.test(c)) return 'Refusé par le serveur. Un administrateur existe peut-être déjà : demandez-lui de créer votre compte.';
    if (/operation-not-allowed/.test(c)) return 'La connexion par e-mail et mot de passe n’est pas activée dans Firebase (voir le guide, étape 2).';
    if (/api-key|invalid-api/.test(c)) return 'Clé Firebase invalide : vérifiez la configuration.';
    return 'Erreur : ' + (c || 'inconnue');
  }

  /* ---- indicateur d'état (sous le nom de l'application) ---- */
  function pillInfo() {
    if (!CL.cfg || !CLOUD) return null;
    if (!CL.sync) return { cls: 'wait', txt: 'Connexion…' };
    var pend = Object.keys(CL.pend).some(function (k) { return CL.pend[k]; });
    if (!CL.online) return { cls: 'off', txt: pend ? 'Hors ligne · envoi en attente' : 'Hors ligne' };
    if (CL.err) return { cls: 'err', txt: 'Erreur de synchro' };
    if (pend) return { cls: 'wait', txt: 'Envoi en cours…' };
    return { cls: 'ok', txt: 'Synchronisé' };
  }
  function syncSub() { var i = pillInfo(); return i ? ' · <span id="sync-sub" class="sync ' + i.cls + '"><i></i>' + esc(i.txt) + '</span>' : ''; }
  function paintPill() {
    var el = $('#sync-sub'), i = pillInfo(); if (!el || !i) return;
    el.className = 'sync ' + i.cls; el.innerHTML = '<i></i>' + esc(i.txt);
  }
  window.addEventListener('online', function () { CL.online = true; paintPill(); });
  window.addEventListener('offline', function () { CL.online = false; paintPill(); });

  /* ---- démarrage et comptes ---- */
  function setScreen(s, msg) { CL.screen = s; CL.msg = msg || ''; render(); }
  function startCloud(cfg) {
    CL.cfg = cfg; CL.screen = 'wait'; render();
    try { CLOUD.init(cfg); } catch (e) { setScreen('config', 'Configuration refusée : ' + e.message); return; }
    CLOUD.onAuth(onAuth);
  }
  function initCloud() {
    if (!CLOUD) return;
    Promise.all([kvGet('cloudcfg'), kvGet('cloudchoice')]).then(function (r) {
      if (r[0]) { startCloud(r[0]); return; }
      if (!r[1] && !S.companies.length && window.OCPR_NATIVE && window.OCPR_NATIVE.isNative) { CL.firstRun = true; setScreen('choice'); }
    });
  }
  function onAuth(user) {
    if (CL.registering) return;
    if (!user) {
      stopSync(); CL.user = null; CL.role = null; CL.name = '';
      CL.screen = 'login'; applyRole(); render(); return;
    }
    if (CL.user && CL.user.uid === user.uid && CL.role) return;
    CL.user = user; CL.screen = 'wait'; CL.msg = ''; render();
    resolveRole(user).then(function (info) {
      if (!CL.user || CL.user.uid !== user.uid) return;
      if (info === 'offline') { setScreen('needonline'); return; }
      if (!info) { setScreen('denied'); return; }
      CL.role = info.role; CL.name = info.name || CLOUD.shortName(user.email); CL.screen = null;
      kvSet('cloudrole', { email: user.email, role: info.role, name: CL.name });
      applyRole(); startSync(); render();
    });
  }
  /* Rôle : on part du dernier rôle connu pour démarrer tout de suite (même sans réseau), puis on le vérifie en ligne. */
  function resolveRole(user) {
    return kvGet('cloudrole').then(function (c) {
      var cached = c && c.email === user.email ? c : null;
      var live = CLOUD.getStaff(user.email);
      if (cached) {
        live.then(function (st) {
          if (!CL.user || CL.user.uid !== user.uid) return;
          if (st === null) { CLOUD.signOut(); kvSet('cloudrole', null); setScreen('denied'); }
          else if (st.role !== CL.role) { CL.role = st.role; kvSet('cloudrole', { email: user.email, role: st.role, name: st.name || cached.name }); applyRole(); render(); }
        }, function () {});
        return cached;
      }
      return live.then(function (st) { return st; }, function () { return 'offline'; });
    });
  }
  function applyRole() {
    if (CL.role === 'garde') { UI.mode = 'guard'; if (['scan', 'today', 'sync'].indexOf(UI.tab) === -1) UI.tab = 'scan'; }
    else if (CL.role === 'admin') { S.isMaster = true; }
  }

  /* ---- synchronisation des données ---- */
  function startSync() {
    stopSync();
    kvGet('syncbase').then(function (base) {
      if (!base || base._project !== CL.cfg.projectId) base = { _project: CL.cfg.projectId };
      CL.sync = SYNCLIB.create({
        role: CL.role, base: base,
        backend: { set: CLOUD.set, del: CLOUD.del, setParams: CLOUD.setParams },
        onError: function (err, col) { CL.err = (err && (err.code || err.message) || 'erreur') + ' · ' + col; paintPill(); if (UI.tab === 'settings' || UI.tab === 'sync') remoteRefresh(); }
      });
      CL.sync.cols().forEach(function (col) {
        CL.unsubs.push(CLOUD.watch(col, function (changes, initial, meta) { onRemote(col, changes, initial, meta); }, onWatchErr));
      });
      CL.unsubs.push(CLOUD.watchParams(function (doc, initial, meta) { onRemoteParams(doc, meta); }, onWatchErr));
      paintPill();
    });
  }
  function stopSync() {
    CL.unsubs.forEach(function (u) { try { u(); } catch (e) {} });
    CL.unsubs = []; CL.sync = null; CL.pend = {}; CL.err = '';
  }
  function onWatchErr(col, err) { CL.err = (err && (err.code || err.message) || 'erreur') + ' · ' + col; paintPill(); }
  function trackMeta(key, meta) { CL.pend[key] = !!meta.pending; if (!meta.fromCache) { CL.lastSync = Date.now(); CL.err = ''; } paintPill(); }
  function onRemote(col, changes, initial, meta) {
    if (!CL.sync) return;
    var ch = CL.sync.applyRemote(S, col, changes, initial, { ids: meta.ids, fromCache: meta.fromCache });
    trackMeta(col, meta);
    if (ch || initial) save();
    if (ch) remoteRefresh();
  }
  function onRemoteParams(doc, meta) {
    if (!CL.sync) return;
    var ch = CL.sync.applyRemoteParams(S, doc, meta.pending);
    if (ch) normalizeState(S);
    trackMeta('params', meta);
    save();
    if (ch) remoteRefresh();
  }
  function cloudPush() {
    if (!CL.sync) return;
    CL.sync.push(S);
    kvSet('syncbase', CL.sync.base);
    paintPill();
  }
  /* Rafraîchit l'écran après un changement distant, sans interrompre le scan, une saisie ou une fenêtre ouverte. */
  var refreshTimer = null;
  function remoteRefresh() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(function () {
      if (CL.screen) return;
      if (UI.tab === 'scan') { paintRecent(); return; }
      if ($('#modal')) { CL.dirty = true; return; }
      var a = document.activeElement;
      if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) { a.addEventListener('blur', remoteRefresh, { once: true }); return; }
      render();
    }, 400);
  }

  /* ---- écrans de connexion ---- */
  function gateWrap(inner) {
    return '<header class="top"><div class="top-in"><div class="brand"><span class="mark" aria-hidden="true"></span><div><b>Pass-Rewards</b><span>Oceanis Park</span></div></div></div></header><main><div class="gate stack">' + inner + '</div></main>';
  }
  function gateMsg() { return CL.msg ? '<div class="banner" role="alert">' + esc(CL.msg) + '</div>' : ''; }
  function viewGate() {
    var m = gateMsg();
    switch (CL.screen) {
      case 'choice':
        return gateWrap('<div class="card stack"><h2>Bienvenue</h2><p class="muted">Ce téléphone peut travailler de deux façons.</p>' +
          '<button class="btn primary block" data-act="cl-config">Connecter ce téléphone au serveur Oceanis</button>' +
          '<p class="muted small" style="margin-top:6px">Recommandé : tous les téléphones partagent les mêmes cartes et les mêmes passages en temps réel, et les gardiens peuvent scanner même sans réseau.</p>' +
          '<button class="btn block" data-act="cl-local">Utiliser sans serveur (cet appareil seulement)</button></div>');
      case 'config':
        return gateWrap(m + '<div class="card stack"><h2>Connexion au serveur</h2>' +
          '<p class="muted small">Le plus simple : sur un téléphone déjà configuré, ouvrez Réglages → « Inviter un téléphone (QR) », puis scannez ce QR ici.</p>' +
          '<video id="cfg-vid" class="hide" playsinline muted style="width:100%;border-radius:12px;background:#000;max-height:46vh;object-fit:cover"></video>' +
          '<div class="row" style="gap:8px"><button class="btn primary grow" data-act="cl-scan">Scanner le QR d’invitation</button><label class="btn grow" style="cursor:pointer">Photo du QR<input type="file" accept="image/*" id="cfg-photo" class="hide"></label></div>' +
          '<form id="f-cfg" class="stack"><label class="f"><span>Ou collez la configuration Firebase</span><textarea name="cfg" id="cfg-text" rows="6" autocapitalize="none" spellcheck="false" placeholder="{ &quot;apiKey&quot;: &quot;…&quot;, &quot;projectId&quot;: &quot;…&quot;, &quot;appId&quot;: &quot;…&quot; }"></textarea></label>' +
          '<button class="btn primary block" type="submit">Enregistrer et continuer</button></form>' +
          '<button class="btn block" data-act="cl-back">Retour</button></div>');
      case 'login':
        return gateWrap(m + '<form id="f-login" class="card stack"><h2>Connexion</h2>' +
          '<label class="f"><span>Identifiant</span><input name="id" type="text" autocomplete="username" autocapitalize="none" spellcheck="false" required placeholder="ex. portail1 ou votre e-mail"></label>' +
          '<label class="f"><span>Mot de passe</span><input name="pw" type="password" autocomplete="current-password" required></label>' +
          '<p class="small" id="cl-err" role="alert" style="color:var(--laterite);margin:0"></p>' +
          '<button class="btn primary block" type="submit">Se connecter</button></form>' +
          '<div class="card stack"><button class="btn block" data-act="cl-register">Premier démarrage : créer le compte administrateur</button><button class="btn sm block" data-act="cl-unlink">Changer de serveur</button></div>');
      case 'register':
        return gateWrap(m + '<form id="f-register" class="card stack"><h2>Compte administrateur</h2>' +
          '<p class="muted small">À faire une seule fois, par la personne qui gère le programme. Ensuite, c’est cet administrateur qui crée les comptes des gardiens depuis Réglages → Équipe.</p>' +
          '<label class="f"><span>Votre nom</span><input name="name" type="text" autocomplete="name" required placeholder="Mahandry"></label>' +
          '<label class="f"><span>Identifiant (e-mail conseillé)</span><input name="id" type="text" autocomplete="username" autocapitalize="none" spellcheck="false" required></label>' +
          '<label class="f"><span>Mot de passe (6 caractères minimum)</span><input name="pw" type="password" autocomplete="new-password" minlength="6" required></label>' +
          '<label class="f"><span>Confirmer le mot de passe</span><input name="pw2" type="password" autocomplete="new-password" minlength="6" required></label>' +
          '<p class="small" id="cl-err" role="alert" style="color:var(--laterite);margin:0"></p>' +
          '<div class="row" style="gap:8px"><button class="btn grow" type="button" data-act="cl-login">Retour</button><button class="btn primary grow" type="submit">Créer</button></div></form>');
      case 'denied':
        return gateWrap('<div class="card stack"><h2>Compte non autorisé</h2><p class="muted">Ce compte existe mais n’a pas été ajouté à l’équipe. Demandez à l’administrateur de le créer depuis Réglages → Équipe.</p><button class="btn block" data-act="cl-logout-now">Changer de compte</button></div>');
      case 'needonline':
        return gateWrap('<div class="card stack"><h2>Réseau requis</h2><p class="muted">La première ouverture d’un compte sur ce téléphone demande Internet. Les ouvertures suivantes fonctionnent sans réseau.</p><button class="btn primary block" data-act="cl-retry">Réessayer</button><button class="btn block" data-act="cl-logout-now">Changer de compte</button></div>');
      default:
        return gateWrap('<div class="card stack"><h2>Connexion…</h2><p class="muted">Ouverture de la session.</p><button class="btn sm block" data-act="cl-logout-now">Annuler</button></div>');
    }
  }
  function errShow(text) { var e = $('#cl-err'); if (e) e.textContent = text; }
  function busyBtn(form, on) { var b = form.querySelector('button[type=submit]'); if (b) b.disabled = on; }

  /* ---- scan du QR d'invitation ---- */
  function cfgScanStop() {
    cfgCam.on = false; clearTimeout(cfgCam.timer);
    if (cfgCam.stream) { cfgCam.stream.getTracks().forEach(function (t) { t.stop(); }); cfgCam.stream = null; }
    var v = $('#cfg-vid'); if (v) { v.srcObject = null; v.classList.add('hide'); }
  }
  function cfgScanStart() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { CL.msg = 'Caméra indisponible : utilisez « Photo du QR » ou collez la configuration.'; render(); return; }
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 } }, audio: false }).then(function (stream) {
      var v = $('#cfg-vid'); if (!v) { stream.getTracks().forEach(function (t) { t.stop(); }); return; }
      cfgCam.stream = stream; cfgCam.on = true; v.srcObject = stream; v.classList.remove('hide');
      var det = null; try { det = ('BarcodeDetector' in window) ? new BarcodeDetector({ formats: ['qr_code'] }) : null; } catch (e) {}
      var cv = document.createElement('canvas');
      (function loop() {
        if (!cfgCam.on) return;
        var vid = $('#cfg-vid'); if (!vid || !vid.videoWidth) { cfgCam.timer = setTimeout(loop, 150); return; }
        var next = function () { cfgCam.timer = setTimeout(loop, 150); };
        if (det) { det.detect(vid).then(function (r) { if (r && r[0]) gotCfg(r[0].rawValue); else next(); }).catch(function () { det = null; next(); }); return; }
        var s = Math.min(1, 720 / vid.videoWidth); cv.width = Math.round(vid.videoWidth * s); cv.height = Math.round(vid.videoHeight * s);
        var ctx = cv.getContext('2d', { willReadFrequently: true }); ctx.drawImage(vid, 0, 0, cv.width, cv.height);
        var d = ctx.getImageData(0, 0, cv.width, cv.height), res = jsQR(d.data, d.width, d.height, { inversionAttempts: 'dontInvert' });
        if (res && res.data) gotCfg(res.data); else next();
      })();
      v.play();
    }).catch(function () { CL.msg = 'Accès à la caméra refusé. Utilisez « Photo du QR » ou collez la configuration.'; render(); });
  }
  function cfgPhoto(file) {
    createImageBitmap(file).then(function (bmp) {
      var s = Math.min(1, 1400 / Math.max(bmp.width, bmp.height)), cv = document.createElement('canvas'); cv.width = Math.round(bmp.width * s); cv.height = Math.round(bmp.height * s);
      var ctx = cv.getContext('2d', { willReadFrequently: true }); ctx.drawImage(bmp, 0, 0, cv.width, cv.height);
      var d = ctx.getImageData(0, 0, cv.width, cv.height), res = jsQR(d.data, d.width, d.height, { inversionAttempts: 'attemptBoth' });
      if (res && res.data) gotCfg(res.data); else setScreen('config', 'QR non lu : rapprochez-vous, évitez les reflets.');
    }).catch(function () { setScreen('config', 'Image illisible.'); });
  }
  function gotCfg(raw) {
    cfgScanStop();
    var cfg = parseConfig(raw);
    if (!cfg) { setScreen('config', 'Ce n’est pas une configuration Firebase valide (il faut au moins apiKey, projectId et appId).'); return; }
    if (navigator.vibrate) navigator.vibrate(60);
    kvSet('cloudcfg', cfg).then(function () { kvSet('cloudchoice', 'cloud'); CL.firstRun = false; startCloud(cfg); });
  }

  /* ---- fenêtres : invitation et équipe ---- */
  function inviteModal() {
    var q = qrcode(0, 'L'); q.addData('OCPRCFG:' + JSON.stringify(CL.cfg)); q.make();
    openModal('<h2>Inviter un téléphone</h2><p class="muted small">Sur le nouveau téléphone, ouvrez l’application, choisissez « Connecter au serveur » puis scannez ce QR. Il contient l’adresse de votre serveur, pas de mot de passe : chaque personne se connecte ensuite avec son propre compte.</p>' +
      '<div style="text-align:center;margin:12px 0;background:#fff;padding:10px;border-radius:12px">' + q.createImgTag(4, 4, 'QR d’invitation').replace('<img', '<img style="max-width:100%;height:auto"') + '</div>' +
      '<button class="btn block" data-act="modal-close">Fermer</button>');
  }
  function teamModal() {
    openModal('<h2>Équipe</h2><div id="team-list" class="muted small">Chargement…</div>' +
      '<form id="f-staff" class="stack" style="margin-top:14px"><h3>Ajouter un compte</h3>' +
      '<label class="f"><span>Nom affiché (ex. Portail principal)</span><input name="name" type="text" required></label>' +
      '<div class="grid2"><label class="f"><span>Identifiant</span><input name="id" type="text" autocapitalize="none" spellcheck="false" required placeholder="portail1"></label>' +
      '<label class="f"><span>Mot de passe</span><input name="pw" type="text" autocapitalize="none" spellcheck="false" minlength="6" required placeholder="6 caractères min."></label></div>' +
      '<label class="f"><span>Rôle</span><select name="role"><option value="garde">Poste de garde (scan uniquement)</option><option value="admin">Administrateur (accès complet)</option></select></label>' +
      '<p class="small" id="cl-err" role="alert" style="color:var(--laterite);margin:0"></p>' +
      '<p class="muted small" style="margin:0">Pour changer un mot de passe : retirez le compte puis créez-en un nouveau avec un autre identifiant.</p>' +
      '<div class="row" style="gap:8px"><button class="btn grow" type="button" data-act="modal-close">Fermer</button><button class="btn primary grow" type="submit">Ajouter</button></div></form>');
    loadTeam();
  }
  function loadTeam() {
    CLOUD.listStaff().then(function (list) {
      var box = $('#team-list'); if (!box) return;
      list.sort(function (a, b) { return (a.role === b.role ? 0 : a.role === 'admin' ? -1 : 1) || String(a.name).localeCompare(b.name); });
      box.innerHTML = '<div class="list">' + list.map(function (u) {
        var me = CL.user && u.email === CL.user.email;
        return '<div class="row between" style="gap:8px;padding:6px 0"><div class="grow"><b>' + esc(u.name || '') + '</b> <span class="muted">' + esc(CLOUD.shortName(u.email)) + '</span><div class="small muted">' + (u.role === 'admin' ? 'Administrateur' : 'Poste de garde') + (me ? ' · vous' : '') + '</div></div>' +
          (me ? '' : '<button class="btn sm danger" data-act="cl-team-del" data-email="' + esc(u.email) + '">Retirer</button>') + '</div>';
      }).join('') + '</div>';
    }, function (e) { var box = $('#team-list'); if (box) box.textContent = 'Liste indisponible : ' + authMsg(e); });
  }

  /* ---- vues branchées dans l'application ---- */
  function cloudCard() {
    if (!CLOUD) return '';
    if (!CL.cfg) return '<div class="card"><h3>Synchronisation multi-téléphones</h3><p class="muted small" style="margin:6px 0 10px">Connectez ce téléphone à votre serveur Firebase : entreprises, cartes et passages sont alors partagés en temps réel entre tous les téléphones, et les gardiens scannent même sans réseau.</p><button class="btn primary block" data-act="cl-config">Connecter à un serveur</button></div>';
    if (!cloudOn()) return '<div class="card"><h3>Synchronisation multi-téléphones</h3><p class="muted small">Connexion en cours…</p></div>';
    var i = pillInfo();
    return '<div class="card"><h3>Synchronisation multi-téléphones</h3><p style="margin:6px 0"><span class="sync ' + i.cls + '" id="sync-sub2"><i></i><b>' + esc(i.txt) + '</b></span></p>' +
      '<p class="muted small" style="margin:0 0 10px">Compte : ' + esc(CL.name) + ' (' + esc(CLOUD.shortName(CL.user.email)) + ') · ' + roleLabel() +
      '<br>Dernière réception du serveur : ' + (CL.lastSync ? tstr(CL.lastSync) : 'pas encore') +
      (CL.err ? '<br><b style="color:var(--laterite)">Erreur : ' + esc(CL.err) + '</b>' : '') + '</p>' +
      '<div class="stack"><button class="btn primary block" data-act="cl-invite">Inviter un téléphone (QR)</button><button class="btn block" data-act="cl-team">Équipe et postes de garde</button><button class="btn block" data-act="cl-logout">Se déconnecter</button></div></div>';
  }
  function viewGuardAccount() {
    var i = pillInfo() || { cls: 'wait', txt: '…' };
    return '<div class="stack"><h2>Compte</h2>' +
      '<div class="card"><h3>Ce poste</h3><p style="margin:6px 0"><span class="sync ' + i.cls + '"><i></i><b>' + esc(i.txt) + '</b></span></p>' +
      '<p class="muted small" style="margin:0 0 10px">Connecté : ' + esc(CL.name) + ' (' + esc(CLOUD.shortName(CL.user.email)) + ')<br>' + S.cards.length + ' carte(s) en mémoire · dernière réception du serveur : ' + (CL.lastSync ? tstr(CL.lastSync) : 'pas encore') + (CL.err ? '<br><b style="color:var(--laterite)">Erreur : ' + esc(CL.err) + '</b>' : '') + '</p>' +
      '<label class="f"><span>Nom du poste (inscrit sur chaque passage)</span><input type="text" id="dev-label" value="' + esc(S.deviceLabel || CL.name) + '" placeholder="Portail principal"></label></div>' +
      '<div class="card"><p class="muted small" style="margin:0 0 10px">Sans réseau, le scan continue avec les dernières données reçues. Les passages partent automatiquement dès que la connexion revient.</p><button class="btn block" data-act="cl-logout">Se déconnecter</button></div></div>';
  }

  /* ---- actions ---- */
  var CLH = {
    'cl-config': function () { CL.firstRun = CL.firstRun || false; setScreen('config'); },
    'cl-local': function () { kvSet('cloudchoice', 'local'); CL.firstRun = false; setScreen(null); },
    'cl-back': function () { cfgScanStop(); setScreen(CL.cfg ? 'login' : (CL.firstRun ? 'choice' : null)); },
    'cl-scan': cfgScanStart,
    'cl-login': function () { setScreen('login'); },
    'cl-register': function () { setScreen('register'); },
    'cl-retry': function () { CL.user = null; onAuth(CLOUD.currentUser()); },
    'cl-logout-now': function () { CLOUD.signOut().then(null, function () {}); },
    'cl-logout': function () { ask('Se déconnecter ?', 'Les données restent sur ce téléphone, mais il faudra se reconnecter (avec du réseau) pour reprendre.', 'Se déconnecter').then(function (ok) { if (ok) { kvSet('cloudrole', null); CLOUD.signOut(); } }); },
    'cl-unlink': function () {
      ask('Changer de serveur ?', 'Ce téléphone sera déconnecté du serveur actuel. Les données déjà présentes sur le téléphone sont conservées.', 'Déconnecter', true).then(function (ok) {
        if (!ok) return;
        Promise.all([kvSet('cloudcfg', null), kvSet('syncbase', null), kvSet('cloudrole', null), kvSet('cloudchoice', null)]).then(function () {
          var done = function () { location.reload(); };
          CLOUD.signOut().then(done, done);
        });
      });
    },
    'cl-invite': inviteModal,
    'cl-team': teamModal,
    'cl-team-del': function (el) {
      var email = el.dataset.email;
      ask('Retirer ce compte ?', CLOUD.shortName(email) + ' ne pourra plus se connecter à l’application.', 'Retirer', true).then(function (ok) {
        if (ok) CLOUD.removeStaff(email).then(loadTeam, function (e) { toast(authMsg(e)); });
      });
    }
  };
  document.addEventListener('submit', function (e) {
    var f = e.target, d, fid = f.getAttribute && f.getAttribute('id');   // f.id serait masqué par le champ « id »
    if (fid === 'f-cfg') {
      e.preventDefault(); var cfg = parseConfig(new FormData(f).get('cfg'));
      if (!cfg) { setScreen('config', 'Configuration invalide : il faut au moins apiKey, projectId et appId.'); return; }
      gotCfg(JSON.stringify(cfg));
    } else if (fid === 'f-login') {
      e.preventDefault(); d = new FormData(f); busyBtn(f, true); errShow('');
      CLOUD.signIn(d.get('id'), d.get('pw')).then(null, function (err) { busyBtn(f, false); errShow(authMsg(err)); });
    } else if (fid === 'f-register') {
      e.preventDefault(); d = new FormData(f);
      if (d.get('pw') !== d.get('pw2')) { errShow('Les deux mots de passe sont différents.'); return; }
      busyBtn(f, true); errShow(''); CL.registering = true;
      CLOUD.registerFirstAdmin(d.get('id'), d.get('pw'), String(d.get('name')).trim()).then(function () {
        CL.registering = false; CL.user = null; onAuth(CLOUD.currentUser());
      }, function (err) { CL.registering = false; busyBtn(f, false); errShow(authMsg(err)); });
    } else if (fid === 'f-staff') {
      e.preventDefault(); d = new FormData(f); busyBtn(f, true); errShow('');
      CLOUD.addStaff(d.get('id'), d.get('pw'), String(d.get('name')).trim(), d.get('role')).then(function () {
        busyBtn(f, false); f.reset(); toast('Compte créé.'); loadTeam();
      }, function (err) { busyBtn(f, false); errShow(authMsg(err)); });
    }
  });
  document.addEventListener('change', function (e) { if (e.target.id === 'cfg-photo' && e.target.files[0]) { cfgPhoto(e.target.files[0]); e.target.value = ''; } });
